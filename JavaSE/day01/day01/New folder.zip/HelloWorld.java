public class HelloWorld{
public static void main(String args[]){
		if(args[0].equals("-name"))
		System.out.println("Hello"+args[0]);
		
	}
}